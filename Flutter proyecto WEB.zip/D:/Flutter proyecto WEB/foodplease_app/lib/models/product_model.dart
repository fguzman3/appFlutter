class Product {
  final int id;
  final String nombre;
  final double precio;
  final double cantidad;
  final String descripcion; // Si estás usando este campo

  Product({
    required this.id,
    required this.nombre,
    required this.precio,
    required this.cantidad,
    required this.descripcion, // Si estás usando este campo
  });

  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      id: json['id'] ?? 0, // Asegura que nunca sea null
      nombre: json['nombre'] ?? 'Sin nombre', // Asegura que nunca sea null
      precio: json['precio'] != null ? json['precio'].toDouble() : 0.0, // Manejo de null y conversión a double
      descripcion: json['descripcion'] ?? '',
      cantidad: json['cantidad'] != null ? json['cantidad'].toDouble() : 0.0// Asegura que nunca sea null
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'nombre': nombre,
      'precio': precio,
      'descripcion': descripcion,
      'cantidad': cantidad
    };
  }
}
