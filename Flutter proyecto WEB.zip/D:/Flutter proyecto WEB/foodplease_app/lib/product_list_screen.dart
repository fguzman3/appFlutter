import 'package:flutter/material.dart';
import './models/product_model.dart';
import './services/product_service.dart';

// Clase principal que muestra la lista de productos
class ProductListScreen extends StatefulWidget {
  const ProductListScreen({super.key});

  @override
  _ProductListScreenState createState() => _ProductListScreenState();
}

class _ProductListScreenState extends State<ProductListScreen> {
  late Future<List<Product>> futureProducts;
  final ProductService productService = ProductService();

  @override
  void initState() {
    super.initState();
    futureProducts = productService.fetchProducts();
  }

  void refreshProducts() {
    setState(() {
      futureProducts = productService.fetchProducts();
    });
  }

  @override
  Widget build(BuildContext context) {
    final isMobile = MediaQuery.of(context).size.width < 600;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tabla de productos'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () async {
              final newProduct = await showDialog<Product>(
                context: context,
                builder: (context) => ProductFormDialog(),
              );
              if (newProduct != null) {
                await productService.createProduct(newProduct);
                refreshProducts();
              }
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: FutureBuilder<List<Product>>(
          future: futureProducts,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            } else if (snapshot.hasError) {
              return Center(child: Text('Error: ${snapshot.error}'));
            } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return const Center(child: Text('No hay productos disponibles'));
            } else {
              return isMobile
                  ? buildMobileLayout(snapshot.data!)
                  : buildDesktopLayout(snapshot.data!);
            }
          },
        ),
      ),
    );
  }

  Widget buildDesktopLayout(List<Product> products) {
    return Column(
      children: [
        Expanded(
          child: DataTable(
            columns: const <DataColumn>[
              DataColumn(label: Text('ID')),
              DataColumn(label: Text('Nombre')),
              DataColumn(label: Text('Precio')),
              DataColumn(label: Text('Acciones')),
            ],
            rows: products
                .map(
                  (product) => DataRow(
                cells: <DataCell>[
                  DataCell(Text('${product.id}')),
                  DataCell(Text(product.nombre)),
                  DataCell(Text('${product.precio}')),
                  DataCell(Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit),
                        onPressed: () async {
                          final updatedProduct = await showDialog<Product>(
                            context: context,
                            builder: (context) =>
                                ProductFormDialog(product: product),
                          );
                          if (updatedProduct != null) {
                            await productService
                                .updateProduct(updatedProduct);
                            refreshProducts();
                          }
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete),
                        onPressed: () async {
                          await productService.deleteProduct(product.id);
                          refreshProducts();
                        },
                      ),
                    ],
                  )),
                ],
              ),
            )
                .toList(),
          ),
        ),
      ],
    );
  }

  Widget buildMobileLayout(List<Product> products) {
    return ListView(
      children: products
          .map(
            (product) => ListTile(
          title: Text(product.nombre),
          subtitle: Text('Precio: ${product.precio}'),
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              IconButton(
                icon: const Icon(Icons.edit),
                onPressed: () async {
                  final updatedProduct = await showDialog<Product>(
                    context: context,
                    builder: (context) =>
                        ProductFormDialog(product: product),
                  );
                  if (updatedProduct != null) {
                    await productService.updateProduct(updatedProduct);
                    refreshProducts();
                  }
                },
              ),
              IconButton(
                icon: const Icon(Icons.delete),
                onPressed: () async {
                  await productService.deleteProduct(product.id);
                  refreshProducts();
                },
              ),
            ],
          ),
        ),
      )
          .toList(),
    );
  }
}

// Clase para el diálogo emergente donde se agregan o editan productos
class ProductFormDialog extends StatefulWidget {
  final Product? product;

  const ProductFormDialog({Key? key, this.product}) : super(key: key);

  @override
  _ProductFormDialogState createState() => _ProductFormDialogState();
}

class _ProductFormDialogState extends State<ProductFormDialog> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nombreController;
  late TextEditingController _precioController;
  late TextEditingController _descripcionController;
  late TextEditingController _cantidadController;

  @override
  void initState() {
    super.initState();
    _nombreController = TextEditingController(text: widget.product?.nombre ?? '');
    _precioController = TextEditingController(text: widget.product?.precio.toString() ?? '');
    _descripcionController = TextEditingController(text: widget.product?.descripcion ?? '');
    _cantidadController = TextEditingController(text: widget.product?.cantidad.toString() ?? '');
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.product == null ? 'Agregar Producto' : 'Editar Producto'),
      content: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextFormField(
              controller: _nombreController,
              decoration: const InputDecoration(labelText: 'Nombre'),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Por favor ingrese un nombre';
                }
                return null;
              },
            ),
            TextFormField(
              controller: _precioController,
              decoration: const InputDecoration(labelText: 'Precio'),
              keyboardType: TextInputType.number,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Por favor ingrese un precio';
                }
                if (double.tryParse(value) == null) {
                  return 'Por favor ingrese un número válido';
                }
                return null;
              },
            ),
            TextFormField(
              controller: _descripcionController,
              decoration: const InputDecoration(labelText: 'Descripción'),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Por favor ingrese una descripción';
                }
                return null;
              },
            ),
            TextFormField(
              controller: _cantidadController,
              decoration: const InputDecoration(labelText: 'Cantidad'),
              keyboardType: TextInputType.number,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Por favor ingrese una cantidad';
                }
                if (int.tryParse(value) == null) {
                  return 'Por favor ingrese un número válido';
                }
                return null;
              },
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancelar'),
        ),
        ElevatedButton(
          onPressed: () {
            if (_formKey.currentState!.validate()) {
              final product = Product(
                id: widget.product?.id ?? 0,
                nombre: _nombreController.text,
                precio: double.parse(_precioController.text),
                descripcion: _descripcionController.text,
                cantidad: double.parse(_cantidadController.text),
              );
              Navigator.of(context).pop(product);
            }
          },
          child: Text(widget.product == null ? 'Agregar' : 'Guardar'),
        ),
      ],
    );
  }

  @override
  void dispose() {
    _nombreController.dispose();
    _precioController.dispose();
    _descripcionController.dispose();
    _cantidadController.dispose();
    super.dispose();
  }
}
