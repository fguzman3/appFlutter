Profesor:

El Backend corresponde a los archivos:

- db_init.js => Inicializa la base de datos en sqlite3
- index.js => Backend con los endpoints para trabajar en localhost
- package.json

1º Debe realizar npm install con el archivo package.json
2º Debe ejecutar node db_init.js para iniciar la base de datos
3º Debe ejecutar index.js para iniciar el servicio backend

En el IDE que usted utilice debe cargar la carpeta de proyecto que se encuentra en el zip
y despues realizar flutter pub get para descargar cualquier dependencia que falte.

Ejecutar la aplicación.

NOTA: Entre la aplicación en flutter y el backend puede existir un probable problema de
conectividad, una solucion es colocar la IP que le deje a la aplicacion para que conecte
con el backend, desconozco si esa modificación pueda servir en su entorno.
