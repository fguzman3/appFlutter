const sqlite3 = require("sqlite3").verbose();

const db = new sqlite3.Database("sqlite.db");

db.serialize(() => {
  // Crear la tabla productos
  db.run(
    `
        CREATE TABLE IF NOT EXISTS productos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            descripcion TEXT,
            cantidad INTEGER NOT NULL,
            precio REAL NOT NULL
        )
    `,
    (err) => {
      if (err) {
        console.error("Error al crear la tabla productos:", err.message);
      } else {
        console.log("Tabla productos creada exitosamente.");
      }
    }
  );

  // Preparar la inserción de registros
  const stmt = db.prepare(
    `INSERT INTO productos (nombre, descripcion, cantidad, precio) VALUES (?, ?, ?, ?)`
  );

  // Insertar 30 registros
  const productos = [
    ["Manzana", "Manzana roja fresca", 50, 0.99],
    ["Banana", "Banana madura", 100, 0.69],
    ["Leche", "Leche entera 1L", 30, 1.2],
    ["Pan", "Pan de molde", 40, 1.5],
    ["Cereal", "Cereal integral", 20, 3.99],
    ["Yogur", "Yogur de fresa", 60, 0.89],
    ["Queso", "Queso cheddar 200g", 25, 2.99],
  ];

  productos.forEach((producto) => {
    stmt.run(producto, (err) => {
      if (err) {
        console.error("Error al insertar producto:", err.message);
      }
    });
  });

  // Finalizar la inserción
  stmt.finalize((err) => {
    if (err) {
      console.error("Error al finalizar la inserción:", err.message);
    } else {
      console.log("30 productos insertados exitosamente.");
    }
  });
});

// Cerrar la base de datos al terminar las operaciones (opcional)
db.close((err) => {
  if (err) {
    console.error("Error al cerrar la base de datos:", err.message);
  } else {
    console.log("Base de datos cerrada.");
  }
});
