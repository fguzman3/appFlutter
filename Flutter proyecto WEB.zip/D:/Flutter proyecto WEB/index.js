const express = require("express");
const sqlite = require("sqlite3").verbose();
const cors = require("cors");

const app = express();
const db = new sqlite.Database("sqlite.db");

app.use(express.json());
app.use(cors());

app.get("/productos/:id", (req, res) => {
  let sql = `SELECT id, nombre, precio, descripcion FROM productos WHERE id = ?`;
  let resp = {};

  db.get(sql, [req.params.id], (err, row) => {
    if (err) {
      res.status(500).json({ error: err });
    }

    if (!row) {
      res.status(404).json({ Error: "producto no encontrado." });
    } else {
      resp = {
        id: row.id,
        nombre: row.nombre,
        precio: row.precio,
        descripcion: row.descripcion,
      };
      res.json(resp);
    }
  });
});

app.get("/productos/", (req, res) => {
  let sql = `SELECT id, nombre, precio, cantidad, descripcion FROM productos`;
  let resp = [];

  db.all(sql, [], (err, rows) => {
    if (err) {
      res.status(500).json({ error: err });
    }

    if (!rows) {
      res.status(404).json({ Error: "producto no encontrado." });
    } else {
      rows.forEach((row) => {
        resp.push({
          id: row.id,
          nombre: row.nombre,
          precio: row.precio,
          descripcion: row.descripcion,
          cantidad: row.cantidad,
        });
      });
      res.json(resp);
    }
  });
});

app.post("/productos", (req, res) => {
  let nombre = req.body.nombre;
  let descripcion = req.body.descripcion;
  let cantidad = Number(req.body.cantidad);
  let precio = Number(req.body.precio);

  if (!nombre || !descripcion || cantidad <= 0 || precio <= 0) {
    return res.status(400).json({
      error:
        "Datos inválidos. Verifica que todos los campos estén llenos y que cantidad y precio sean mayores a 0.",
    });
  }

  let sql = `INSERT INTO productos(nombre, descripcion, cantidad, precio) values(?,?,?,?)`;

  db.run(sql, [nombre, descripcion, cantidad, precio], function (err) {
    if (err) {
      return console.log(err);
    }

    res.status(201).json({ message: "Producto creado con éxito." });
  });
});

app.put("/productos/:id", (req, res) => {
  let sql = `UPDATE productos SET nombre = ?, precio = ?, cantidad = ?, descripcion = ? WHERE id = ?`;

  let nombre = req.body.nombre;
  let precio = Number(req.body.precio);
  let cantidad = Number(req.body.cantidad);
  let descripcion = req.body.descripcion;

  db.run(
    sql,
    [nombre, precio, cantidad, descripcion, req.params.id],
    function (err) {
      if (err) {
        return res.status(400).send();
      }

      return res.status(200).json({ msg: "Producto actualizado" });
    }
  );
});

app.delete("/productos/:id", (req, res) => {
  let sql = `DELETE FROM productos WHERE id = ?`;
  db.run(sql, Number(req.params.id), function (err) {
    if (err) {
      return console.log(err);
    }

    res.status(200).json({ msg: "Registro borrado." });
  });
});

app.listen(8000, () => {
  console.log("Servidor corriendo.");
});
